package mpu.fca.comp221;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TestAppFX  extends Application {

	private Scene welcomePage;
	
	public void CreateWelcomePage() {
        VBox root = new VBox(10);
        root.setPrefSize(800, 600);
        root.setAlignment(Pos.TOP_CENTER);

        welcomePage = new Scene(root, 800, 600);
        welcomePage.getStylesheets().add(getClass().getResource("testApplication.css").toExternalForm());

        Label lTitle = new Label("This is the Welcome Page");
        lTitle.getStyleClass().add("labelTitle");
        Label lAbout = new Label("Course: COMP221 Object Oriented Technology");
        lAbout.getStyleClass().add("labelContent");

        Button btnSample1 = new Button("Sample App 1");
        btnSample1.setOnAction(e -> {
        	ShapeCalculatorFX shapCalculator = new ShapeCalculatorFX();
        	
        	Stage window = (Stage)btnSample1.getScene().getWindow();
        	window.setTitle("Shape Calculator");
        	window.setScene(new Scene(shapCalculator.CreateContent()));
        });
        
        Button btnSample2 = new Button("Sample App 2");
        btnSample2.setOnAction(e -> {
        	SimpleMazeFX simpleMaze = new SimpleMazeFX();
        	Scene scene = new Scene(simpleMaze.CreateContent());
        	scene.setOnKeyPressed(event -> simpleMaze.MovePlayer(event.getCode()));

        	Stage window = (Stage)btnSample2.getScene().getWindow();
        	window.setTitle("Simple Maze Game");
        	window.setScene(scene);
        });
        
        root.getChildren().addAll(lTitle, lAbout, btnSample1, btnSample2);
    }
	
	@Override
    public void start(Stage stage) throws Exception {
    	stage.setTitle("JavaFX Samples");
    	CreateWelcomePage();
    	stage.setScene(welcomePage);
	    stage.show();
	}

    public static void main(String[] args) {
        launch(args);
    }
}
