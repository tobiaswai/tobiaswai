package mpu.fca.comp221;

import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class ShapeCalculatorFX {
	private TextArea output = new TextArea();

    public Parent CreateContent() {
        VBox root = new VBox(10);
        root.setPrefSize(800, 600);
        root.setPadding(new Insets(15));

        TextField widthInputField = new TextField();
        TextField heightInputField = new TextField();
        
        GridPane inputPanel = new GridPane();
        inputPanel.add(new Label("Width  : "), 1, 1);
        inputPanel.add(widthInputField, 2, 1);
        inputPanel.add(new Label("Height : "), 1, 2);
        inputPanel.add(heightInputField, 2, 2);
                
        Button btnRect = new Button("Rectangle");
        btnRect.setOnAction(e -> calculate( new Rectangle(
        													CreateBean( widthInputField.getText(), heightInputField.getText() )
        													)
        									)
        					);

        Button btnTri = new Button("Triangle");
        btnTri.setOnAction(e -> calculate( new Triangle(
        													CreateBean( widthInputField.getText(), heightInputField.getText() )
        													)
        									)
        					);

        Button btnEllipse = new Button("Ellipse");
        btnEllipse.setOnAction(e -> calculate( new Ellipse(
															CreateBean( widthInputField.getText(), heightInputField.getText() )
															)
        									)
        					);

        output.setPrefHeight(450);
        output.setFont(Font.font(26));
        output.setEditable(false);

        root.getChildren().addAll(inputPanel, btnRect, btnTri, btnEllipse, output);

        return root;
    }
    
    private ShapeBean CreateBean(final String inWitdthStr, final String inHeightStr) {
    	double inWidth;
    	double inHeight;
    	
    	try {
    		inWidth = Math.abs(Double.parseDouble(inWitdthStr));
        } catch (Exception ex) {
        	Alert alert = new Alert(AlertType.ERROR);
        	alert.setTitle("Error Input");
        	alert.setHeaderText("Mismatch input for the Width value");
        	alert.setContentText("Width will set to ZERO");
        	alert.showAndWait();
        	inWidth = 0;
        }
    	try {
    		inHeight = Math.abs(Double.parseDouble(inHeightStr));
    	} catch (Exception ex) {
        	Alert alert = new Alert(AlertType.ERROR);
        	alert.setTitle("Error Input");
        	alert.setHeaderText("Mismatch input for the Height value");
        	alert.setContentText("Height will set to ZERO");
        	alert.showAndWait();
    		inHeight = 0;
    	}
    	
    	ShapeBean bean = new ShapeBean();
    	bean.setWidth(inWidth);
		bean.setHeight(inHeight);

		return bean;
    }
    
    private void calculate(Shape shape) {
    	output.setText("Area of a " + shape.getName() + " : [" + shape.getBean().getWidth() + " | " + shape.getBean().getHeight() + "] = " + shape.getArea());
    	output.appendText("\nRandom numbers :" + Math.random() * 7 + " | " + Math.random() * 7  + " | " + Math.random() * 7);
	}	    
}

//-------------------------------------------------------------------------
// Classes of your system
class ShapeBean {
	private double width;
	private double height;
	public double getWidth() {		return width;	}
	public void setWidth(final double width) {	this.width = width;	}
	public double getHeight() {		return height;	}
	public void setHeight(final double height) {	this.height = height;	}
}

abstract class Shape {
	protected ShapeBean bean;
	public Shape(final ShapeBean bean) {
		this.bean = bean;
	}
	public String getName() {
		return this.getClass().getSimpleName();
	}
	public ShapeBean getBean() {		return bean;	}
	public void SetBean(ShapeBean bean) {		this.bean = bean;	}
	public double getWxH() {	return bean.getWidth() * bean.getHeight();	}
	abstract public double getArea();
}

class Rectangle extends Shape {
	public Rectangle(final ShapeBean bean) {
		super(bean);
	}
	public double getArea() {
		return getWxH();
	}
}

class Triangle extends Shape {
	public Triangle(final ShapeBean bean) {
		super(bean);
	}
	public double getArea() {
		return 0.5 * getWxH();
	}
}

class Ellipse extends Shape {
	public Ellipse(final ShapeBean bean) {
		super(bean);
	}
	public double getArea() {
		return  Math.PI * getWxH();
	}
}