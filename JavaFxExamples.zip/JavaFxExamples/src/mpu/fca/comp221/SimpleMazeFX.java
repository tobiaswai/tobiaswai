package mpu.fca.comp221;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class SimpleMazeFX{
		
	private int tileSize = 50;
	private int mapWidth = 0;
	private int mapHeight = 0;
	
	private int playerPosX = 0;
	private int playerPosY = 0;
	
	private Node playerTile;
	private Pane root;

	public Parent CreateContent() {
        root = new Pane();

    	mapWidth = MazeData.MAP_1[0].length();
    	mapHeight = MazeData.MAP_1.length;
        int mazeWidth = mapWidth * tileSize;
        int mazeHeight = mapHeight * tileSize;
        
        root.setPrefSize(mazeWidth, mazeHeight);

        // load the image
        Image image = new Image("/mpu/fca/comp221/media/mpu_logo.png");

        // Original Image
        ImageView imageView = new ImageView();
        imageView.setImage(image);
        imageView.setFitHeight(mazeHeight);
        imageView.setFitWidth(mazeWidth);
        
        root.getChildren().add(imageView);

        Tile exitTile = new Tile(tileSize, Color.RED, "E" , Color.WHITE, "This is the Exit");
        playerTile = new Tile(tileSize, Color.BLUE, "P", Color.WHITE, "This is the player");

        for (int j = 0; j < mapHeight; j++) {
        	String rowData = MazeData.MAP_1[j];
        	for (int i = 0; i < mapWidth; i++) {
        		switch (rowData.charAt(i)) {
                case '0':
                    break;
                case '1':
                	CreateEntity(i * tileSize, j * tileSize, Color.BROWN);
                    break;
                case 'E':
                	exitTile.setTranslateX(i * tileSize);
                	exitTile.setTranslateY(j * tileSize);
                	root.getChildren().add(exitTile);
                	break;
                case 'S':
                	playerPosX = i;
                	playerPosY = j;
                	playerTile.setTranslateX(i * tileSize);
                	playerTile.setTranslateY(j * tileSize);
                	root.getChildren().add(playerTile);
                    break;
        		}
        	}
        }

        return root;
    }

	public void MovePlayer(KeyCode key) {
		switch(key) {
		case A:
			MovePlayerX(-1);
			break;
		case D:
			MovePlayerX(1);
			break;
		case W:
			MovePlayerY(-1);
			break;
		case S:
			MovePlayerY(1);
			break;
		default:
			break;
		}
	}
	
	// private methods (internal use)
	private void ReachExit()
	{
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Inforamtion");
		alert.setHeaderText("Congradutations!");
		alert.setContentText("Your have reach the exit.");
		alert.showAndWait();
	}
	
    private void MovePlayerX(int value) {
    	int newPosX = playerPosX + value;    	
    	if((newPosX >= 0) && (newPosX < mapWidth))
    	{
        	char mapData = MazeData.getChar(newPosX, playerPosY);
    		double playTranslateX = playerTile.getTranslateX() + value * tileSize;
        	
        	switch(mapData) {
        	 case '0':
        		 playerPosX = newPosX;
        		 playerTile.setTranslateX(playTranslateX);
                 break;
             case '1':
                 break;
             case 'E':
         		playerPosX = newPosX;
         		playerTile.setTranslateX(playTranslateX);
         		ReachExit();
             	break;
             case 'S':
        		playerPosX = newPosX;
        		playerTile.setTranslateX(playTranslateX);
            	break;
        	}
    	}    	
    }
    
    private void MovePlayerY(int value) {
    	int newPosY = playerPosY + value;    	
    	if((newPosY >= 0) && (newPosY < mapHeight))
    	{
        	char mapData = MazeData.getChar(playerPosX, newPosY);
    		double playTranslateY = playerTile.getTranslateY() + value * tileSize;
        	
        	switch(mapData) {
        	 case '0':
        		 playerPosY = newPosY;
        		 playerTile.setTranslateY(playTranslateY);
                 break;
             case '1':
                 break;
             case 'E':
         		playerPosY = newPosY;
         		playerTile.setTranslateY(playTranslateY);
         		ReachExit();
             	break;
             case 'S':
        		playerPosY = newPosY;
        		playerTile.setTranslateY(playTranslateY);
            	break;
        	}
    	}    	
    }
	
    private Node CreateEntity(int x, int y, Color color) {
        Rectangle entity = new Rectangle(tileSize, tileSize);
        entity.setTranslateX(x);
        entity.setTranslateY(y);
        entity.setFill(color);
        root.getChildren().add(entity);
        return entity;
    }
}

// The Tile class for drawing the player and the exit
class Tile extends StackPane {
    private Text text = new Text();
    private String info;
    
    public Tile(double tileSize, Color color, String str, Color textColor, String tileInfo) {
        Rectangle rect = new Rectangle(tileSize, tileSize);
        rect.setFill(color);

        text.setText(str);
        text.setFont(Font.font(30));
        text.setFill(textColor);
        
        info = tileInfo;

        setAlignment(Pos.CENTER);
        getChildren().addAll(rect, text);
        
        setOnMouseClicked(this::handleMouseClick);
    }
    
    public void handleMouseClick(MouseEvent event) {
    	Alert alert = new Alert(AlertType.WARNING);
		alert.setTitle("Inforamtion");
		alert.setHeaderText("Object Information");
		alert.setContentText(info);
		alert.showAndWait();
    }
}

// MazeData class
class MazeData {
    public static final String[] MAP_1 = new String[] {
        "00110000",
        "10000110",
        "11100010",
        "1110001E",
        "10000011",
        "11100000",
        "S0001110",
        "11111111"
    };
    public static char getChar(int x, int y) {
    	return MAP_1[y].charAt(x);
    }
}
