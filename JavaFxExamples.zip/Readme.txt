This file serves as a note to the JavaFX sample project: "JavaFxExample".
Please read through this document before you take action to use/import the sample project.

"JavaFxExample" is a project(folder) created with the Eclipse IDE.

To open and run the program, copy the "JavaFxExample" folder to your workspace and add the project to your IDE.
However, some settinges - such as the JavaFX Library - might be diferent.
You might need to reset the setting to the project.

If you are using a different IDE, or you failed to reset the JavaFX setting of the project,
an alternate way is to create a project with your JavaFX library settings.
And then copy all the source files, the CSS file and the media files (under the "JavaFxExample\src" folder)
to the "src" folder of your new created project.

You might need to copy the CSS file and the media files to the "bin" folder to run the program.
(The path might look like: "(Your_Project)\bin\mpu\fca\comp221\")
Refleshing the project in some of the IDEs (For example, presss F5 in Eclipse) might copy the files to the "bin" automatically.
